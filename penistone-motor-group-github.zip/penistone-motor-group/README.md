# Penistone Motor Group — Vehicle Prep System

Mobile-first internal vehicle intake and preparation system.

## MVP flow

**Scan / enter registration → vehicle lookup → review vehicle data → save vehicle → inspection**

The repository also includes the initial Supabase schema for inspections, work items, locations, location history and audit events.

## Stack

- Next.js + TypeScript
- Tailwind CSS
- Supabase PostgreSQL/Auth
- Cloudflare Workers via OpenNext
- Server-side DVLA/DVSA integration abstraction
- Replaceable ANPR/OCR provider abstraction

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## Configure APIs

Put credentials in `.env.local`:

```text
DVLA_API_URL=
DVLA_API_KEY=
DVSA_API_URL=
DVSA_API_KEY=
OCR_PROVIDER=
OCR_API_URL=
OCR_API_KEY=
```

Do not commit `.env.local`.

The exact DVLA/DVSA request and response mapping should be adapted to the API credentials/endpoints already available to Penistone Motor Group. The starter deliberately does not invent undocumented payloads.

## Supabase

Run `supabase/migrations/001_initial.sql` against the project database.

Before production, tighten the starter RLS policies to match your exact team/role model.

## Cloudflare

The project contains `wrangler.jsonc` and scripts for OpenNext:

```bash
npm run cf:build
npm run cf:preview
npm run cf:deploy
```

Configure production secrets in Cloudflare rather than committing credentials.

## Next development phases

1. Complete exact DVLA/DVSA mappings.
2. Connect Supabase Auth and vehicle inserts.
3. Add live ANPR provider.
4. Build mechanical/exterior/interior inspection screens.
5. Add work routing and garage assignments.
6. Add photography queue.
7. Add Pitch 1 / Pitch 2 / Road / S6 CAF location workflow.
8. Add role-aware RLS and audit UI.
9. Add PWA/offline improvements.

## Important

The scanner uses the browser camera as a live viewfinder. It does not intentionally capture or persist a vehicle photograph. ANPR integration should return plate text/confidence only.
