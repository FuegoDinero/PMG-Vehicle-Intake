export interface PlateRecognitionResult {
  registration: string | null;
  confidence: number;
}

export interface PlateRecognitionProvider {
  recognisePlate(input: unknown): Promise<PlateRecognitionResult>;
}

export function createPlateRecognitionProvider(): PlateRecognitionProvider {
  return {
    async recognisePlate() {
      // Intentionally unimplemented: wire this to Plate Recognizer,
      // Tesseract, or another ANPR provider without changing scanner consumers.
      return { registration: null, confidence: 0 };
    },
  };
}