export type VehicleData = {
  registration: string;
  make?: string;
  model?: string;
  derivative?: string;
  year?: number;
  colour?: string;
  fuel_type?: string;
  transmission?: string;
  engine_capacity?: number;
  date_first_registered?: string;
  mot_status?: string;
  mot_expiry?: string;
  tax_status?: string;
  raw?: unknown;
};

export interface VehicleDataProvider {
  lookupVehicle(registration: string): Promise<VehicleData>;
}

class ConfiguredVehicleProvider implements VehicleDataProvider {
  async lookupVehicle(registration: string): Promise<VehicleData> {
    const dvlaUrl = process.env.DVLA_API_URL;
    const dvlaKey = process.env.DVLA_API_KEY;
    const dvsaUrl = process.env.DVSA_API_URL;
    const dvsaKey = process.env.DVSA_API_KEY;

    // The project deliberately does not invent API payloads.
    // Add the exact request/response mapping for your existing DVLA/DVSA credentials here.
    if (!dvlaUrl || !dvlaKey) {
      return {
        registration,
        make: "API not configured",
        model: "Add DVLA/DVSA credentials",
        mot_status: dvsaUrl && dvsaKey ? "DVSA configured" : "Not configured",
      };
    }

    const response = await fetch(dvlaUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": dvlaKey,
      },
      body: JSON.stringify({ registrationNumber: registration }),
    });

    if (!response.ok) {
      throw new Error(`DVLA lookup failed (${response.status})`);
    }

    const data = await response.json() as Record<string, unknown>;

    return {
      registration,
      make: typeof data.make === "string" ? data.make : undefined,
      model: typeof data.model === "string" ? data.model : undefined,
      year: typeof data.yearOfManufacture === "number" ? data.yearOfManufacture : undefined,
      colour: typeof data.colour === "string" ? data.colour : undefined,
      fuel_type: typeof data.fuelType === "string" ? data.fuelType : undefined,
      engine_capacity: typeof data.engineCapacity === "number" ? data.engineCapacity : undefined,
      date_first_registered: typeof data.monthOfFirstRegistration === "string" ? data.monthOfFirstRegistration : undefined,
      tax_status: typeof data.taxStatus === "string" ? data.taxStatus : undefined,
      raw: data,
    };
  }
}

export async function lookupVehicle(registration: string) {
  return new ConfiguredVehicleProvider().lookupVehicle(registration);
}