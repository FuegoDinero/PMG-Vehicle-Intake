"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";

export default function Scanner() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [registration, setRegistration] = useState("");
  const [cameraError, setCameraError] = useState("");

  useEffect(() => {
    let stream: MediaStream | undefined;

    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
          audio: false,
        });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch {
        setCameraError("Camera access was unavailable. Enter the registration manually.");
      }
    }

    start();
    return () => stream?.getTracks().forEach((track) => track.stop());
  }, []);

  function normalise(value: string) {
    return value.toUpperCase().replace(/[^A-Z0-9]/g, "");
  }

  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-2xl bg-black">
        <video ref={videoRef} autoPlay playsInline muted className="aspect-[4/3] w-full object-cover" />
      </div>

      <div className="rounded-xl border-2 border-dashed border-gray-300 p-6 text-center">
        <p className="font-semibold">Plate detection area</p>
        <p className="mt-1 text-sm text-gray-500">Connect your chosen ANPR/OCR provider to recognise the live plate.</p>
      </div>

      {cameraError && <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">{cameraError}</p>}

      <div className="card">
        <label htmlFor="registration" className="text-sm font-semibold">Registration</label>
        <input
          id="registration"
          value={registration}
          onChange={(e) => setRegistration(normalise(e.target.value))}
          placeholder="AB12CDE"
          className="mt-2 w-full rounded-xl border border-gray-300 p-4 text-xl font-bold uppercase tracking-wider"
          autoCapitalize="characters"
        />
        <p className="mt-2 text-xs text-gray-500">Manual entry is the fallback until an ANPR provider is configured.</p>
        <div className="mt-4 flex gap-3">
          <Link
            href={registration ? `/vehicles/new?registration=${encodeURIComponent(registration)}` : "#"}
            className={`primary flex-1 text-center ${!registration ? "pointer-events-none opacity-40" : ""}`}
          >
            Look Up Vehicle
          </Link>
        </div>
      </div>
    </div>
  );
}