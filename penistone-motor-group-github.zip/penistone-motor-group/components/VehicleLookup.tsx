"use client";

import { useEffect, useState } from "react";

type Vehicle = {
  registration: string;
  make?: string;
  model?: string;
  year?: number;
  colour?: string;
  fuel_type?: string;
  transmission?: string;
  engine_capacity?: number;
  date_first_registered?: string;
  mot_status?: string;
  mot_expiry?: string;
  tax_status?: string;
};

export default function VehicleLookup({ initialRegistration }: { initialRegistration: string }) {
  const [registration, setRegistration] = useState(initialRegistration.toUpperCase());
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function lookup() {
    setLoading(true);
    setMessage("");
    setVehicle(null);
    try {
      const response = await fetch("/api/vehicles/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ registration }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Lookup failed");
      setVehicle(data.vehicle);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Lookup failed");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (registration) lookup();
    // Intentionally only run on initial page load.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const motDays = vehicle?.mot_expiry
    ? Math.ceil((new Date(vehicle.mot_expiry).getTime() - Date.now()) / 86400000)
    : null;

  return (
    <div className="space-y-4">
      <div className="card">
        <label className="text-sm font-semibold">Registration</label>
        <div className="mt-2 flex gap-2">
          <input
            value={registration}
            onChange={(e) => setRegistration(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))}
            className="min-w-0 flex-1 rounded-xl border border-gray-300 p-4 text-lg font-bold"
          />
          <button onClick={lookup} disabled={loading || !registration} className="primary disabled:opacity-50">
            {loading ? "..." : "Look up"}
          </button>
        </div>
      </div>

      {message && <div className="rounded-xl bg-red-50 p-4 text-red-700">{message}</div>}

      {vehicle && (
        <div className="card">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm text-gray-500">Vehicle found</p>
              <h2 className="text-2xl font-bold">{vehicle.registration}</h2>
              <p className="text-gray-600">{vehicle.make ?? "Unknown"} {vehicle.model ?? ""}</p>
            </div>
            <span className={`rounded-full px-3 py-1 text-sm font-bold ${motDays !== null && motDays < 0 ? "bg-red-100 text-red-700" : motDays !== null && motDays <= 30 ? "bg-amber-100 text-amber-800" : "bg-green-100 text-green-700"}`}>
              {motDays === null ? "MOT unknown" : motDays < 0 ? "MOT expired" : `MOT ${motDays} days`}
            </span>
          </div>

          <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
            {[
              ["Make", vehicle.make],
              ["Model", vehicle.model],
              ["Year", vehicle.year],
              ["Colour", vehicle.colour],
              ["Fuel", vehicle.fuel_type],
              ["Transmission", vehicle.transmission],
              ["Engine", vehicle.engine_capacity ? `${vehicle.engine_capacity}cc` : undefined],
              ["MOT expiry", vehicle.mot_expiry],
              ["Tax", vehicle.tax_status],
            ].map(([label, value]) => (
              <div key={label as string}>
                <dt className="text-gray-500">{label}</dt>
                <dd className="mt-1 font-semibold">{value ?? "—"}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-6">
            <button className="primary w-full" onClick={() => alert("Connect this button to the Supabase vehicle insert.")}>
              Save Vehicle & Start Inspection
            </button>
          </div>
        </div>
      )}
    </div>
  );
}