"use client";

export default function SplashScreen() {
  return (
    <div className="splash-screen" aria-label="Penistone Motor Group">
      <div className="splash-content">
        <svg
          className="splash-car"
          viewBox="0 0 360 150"
          role="img"
          aria-label="Silver car silhouette"
        >
          <defs>
            <linearGradient id="silverBody" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#ffffff" />
              <stop offset="0.5" stopColor="#c9d0d8" />
              <stop offset="1" stopColor="#7f8a96" />
            </linearGradient>
            <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#253444" />
              <stop offset="1" stopColor="#0a111a" />
            </linearGradient>
          </defs>
          <path
            d="M35 102c10-22 31-31 63-34l31-35c9-10 20-15 35-15h55c18 0 30 5 43 18l27 30c23 4 38 13 48 36l3 16H30z"
            fill="url(#silverBody)"
          />
          <path
            d="M137 39l-25 29h101l-22-29c-7-8-14-11-27-11h-9c-8 0-13 3-18 11z"
            fill="url(#glass)"
          />
          <path d="M31 103h297v15H31z" fill="#aab3bc" />
          <circle cx="88" cy="119" r="25" fill="#0a0d12" />
          <circle cx="88" cy="119" r="12" fill="#87919b" />
          <circle cx="271" cy="119" r="25" fill="#0a0d12" />
          <circle cx="271" cy="119" r="12" fill="#87919b" />
          <path d="M49 92h31M285 92h27" stroke="#e9eef3" strokeWidth="4" strokeLinecap="round" />
        </svg>
        <div className="splash-title">Penistone Motor Group</div>
      </div>
    </div>
  );
}
