export type InspectionResponse = "YES" | "NO" | "NA" | null;

export const inspectionItems = [
  { section: "mechanical", category: "engine", key: "engine_starts", label: "Engine starts correctly" },
  { section: "mechanical", category: "engine", key: "engine_noise", label: "No unusual engine noise" },
  { section: "mechanical", category: "clutch", key: "clutch_feel", label: "Clutch feels normal" },
  { section: "mechanical", category: "brakes", key: "brakes_feel", label: "Brakes feel normal" },
  { section: "mechanical", category: "steering", key: "steering_feel", label: "Steering feels normal" },
  { section: "mechanical", category: "suspension", key: "suspension_noise", label: "No unusual suspension noise" },
  { section: "exterior", category: "bodywork", key: "corrosion", label: "No significant corrosion" },
  { section: "exterior", category: "bodywork", key: "broken_parts", label: "No broken exterior parts" },
  { section: "exterior", category: "glass", key: "windscreen", label: "Windscreen acceptable" },
  { section: "exterior", category: "lights", key: "lights", label: "Exterior lights working" },
  { section: "interior", category: "cabin", key: "interior_condition", label: "Interior acceptable" },
  { section: "interior", category: "controls", key: "controls", label: "Controls functioning" },
] as const;
