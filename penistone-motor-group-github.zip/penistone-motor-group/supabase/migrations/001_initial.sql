create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'viewer' check (role in ('admin','manager','inspector','photographer','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  registration text not null unique,
  make text,
  model text,
  derivative text,
  year integer,
  colour text,
  fuel_type text,
  transmission text,
  engine_capacity integer,
  date_first_registered date,
  mot_status text,
  mot_expiry date,
  tax_status text,
  stock_number text,
  current_stage text not null default 'NEW',
  current_location text,
  status text not null default 'active',
  raw_api_data jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists vehicles_stage_idx on public.vehicles(current_stage);
create index if not exists vehicles_location_idx on public.vehicles(current_location);
create index if not exists vehicles_mot_idx on public.vehicles(mot_expiry);

create table if not exists public.inspections (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  inspector_id uuid references public.profiles(id),
  status text not null default 'IN_PROGRESS',
  notes text,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inspection_items (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid not null references public.inspections(id) on delete cascade,
  section text not null,
  category text not null,
  item_key text not null,
  label text not null,
  response text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.work_items (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  inspection_id uuid references public.inspections(id) on delete set null,
  category text not null,
  description text not null,
  priority text not null default 'normal',
  status text not null default 'AWAITING_WORK',
  assigned_to uuid references public.profiles(id),
  assigned_garage text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists public.locations (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  active boolean not null default true
);

insert into public.locations(name) values
  ('Pitch 1'), ('Pitch 2'), ('Road'), ('S6 CAF')
on conflict (name) do nothing;

create table if not exists public.vehicle_location_history (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  old_location text,
  new_location text not null,
  changed_by uuid references public.profiles(id),
  changed_at timestamptz not null default now()
);

create table if not exists public.audit_events (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid references public.vehicles(id) on delete cascade,
  user_id uuid references public.profiles(id),
  event_type text not null,
  description text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.inspections enable row level security;
alter table public.inspection_items enable row level security;
alter table public.work_items enable row level security;
alter table public.locations enable row level security;
alter table public.vehicle_location_history enable row level security;
alter table public.audit_events enable row level security;

-- Starter policies. Tighten these further around your team's role model before production.
create policy "authenticated users can view vehicles"
on public.vehicles for select to authenticated using (true);

create policy "authenticated users can create vehicles"
on public.vehicles for insert to authenticated with check (true);

create policy "authenticated users can update vehicles"
on public.vehicles for update to authenticated using (true) with check (true);

create policy "authenticated users can view inspections"
on public.inspections for select to authenticated using (true);

create policy "authenticated users can manage inspections"
on public.inspections for all to authenticated using (true) with check (true);

create policy "authenticated users can manage inspection items"
on public.inspection_items for all to authenticated using (true) with check (true);

create policy "authenticated users can manage work items"
on public.work_items for all to authenticated using (true) with check (true);

create policy "authenticated users can view locations"
on public.locations for select to authenticated using (true);

create policy "authenticated users can manage locations"
on public.locations for all to authenticated using (true) with check (true);

create policy "authenticated users can view location history"
on public.vehicle_location_history for select to authenticated using (true);

create policy "authenticated users can create location history"
on public.vehicle_location_history for insert to authenticated with check (true);

create policy "authenticated users can view audit events"
on public.audit_events for select to authenticated using (true);

create policy "authenticated users can create audit events"
on public.audit_events for insert to authenticated with check (true);