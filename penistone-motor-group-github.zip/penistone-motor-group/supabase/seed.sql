-- Optional development seed.
insert into public.locations(name) values
  ('Pitch 1'), ('Pitch 2'), ('Road'), ('S6 CAF')
on conflict (name) do nothing;