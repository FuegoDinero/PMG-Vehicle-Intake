import VehicleLookup from "@/components/VehicleLookup";

export default async function NewVehiclePage({ searchParams }: { searchParams: Promise<{ registration?: string }> }) {
  const params = await searchParams;
  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-2xl p-5 md:p-8">
        <h1 className="text-2xl font-bold">Vehicle Details</h1>
        <p className="mt-1 text-gray-600">Retrieve and review the vehicle before saving it.</p>
        <div className="mt-6"><VehicleLookup initialRegistration={params.registration ?? ""} /></div>
      </div>
    </main>
  );
}