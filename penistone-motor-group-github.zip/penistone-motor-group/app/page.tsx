import Link from "next/link";

const stats = [
  ["Vehicles Today", "0"],
  ["Awaiting Inspection", "0"],
  ["Work Required", "0"],
  ["Ready for Photos", "0"],
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[#05070b]">
      <div className="mx-auto max-w-6xl p-5 md:p-8">
        <header className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-semibold text-slate-400">PENISTONE MOTOR GROUP</p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight">Vehicle Prep</h1>
            <p className="mt-1 text-slate-300">Scan, inspect, prepare and locate vehicles.</p>
          </div>
          <Link href="/scan" className="primary text-center">Scan Vehicle</Link>
        </header>

        <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {stats.map(([label, value]) => (
            <div className="card" key={label}>
              <p className="text-sm text-slate-400">{label}</p>
              <p className="mt-2 text-3xl font-bold">{value}</p>
            </div>
          ))}
        </section>

        <section className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="card">
            <h2 className="text-lg font-bold">Workflow</h2>
            <ol className="mt-4 space-y-3 text-sm text-slate-300">
              <li>1. Scan registration</li>
              <li>2. Retrieve vehicle and MOT information</li>
              <li>3. Complete inspection</li>
              <li>4. Record work required</li>
              <li>5. Ready for photography</li>
              <li>6. Assign physical location</li>
            </ol>
          </div>
          <div className="card">
            <h2 className="text-lg font-bold">MOT attention</h2>
            <p className="mt-3 text-slate-300">Vehicles with expired or soon-to-expire MOTs will appear here once the API is configured.</p>
          </div>
        </section>
      </div>
    </main>
  );
}