import { NextResponse } from "next/server";
import { z } from "zod";
import { lookupVehicle } from "@/lib/vehicle-services";

const schema = z.object({
  registration: z.string().min(2).max(10),
});

export async function POST(request: Request) {
  try {
    const body = schema.parse(await request.json());
    const registration = body.registration.toUpperCase().replace(/[^A-Z0-9]/g, "");
    const vehicle = await lookupVehicle(registration);
    return NextResponse.json({ vehicle });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Vehicle lookup failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}