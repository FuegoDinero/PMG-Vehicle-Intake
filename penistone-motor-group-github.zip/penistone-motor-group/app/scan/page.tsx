import Scanner from "@/components/Scanner";

export default function ScanPage() {
  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-xl p-5 md:p-8">
        <h1 className="text-2xl font-bold">Scan Vehicle</h1>
        <p className="mt-1 text-gray-600">Use the camera as a live plate scanner. No scan image is saved.</p>
        <div className="mt-6"><Scanner /></div>
      </div>
    </main>
  );
}